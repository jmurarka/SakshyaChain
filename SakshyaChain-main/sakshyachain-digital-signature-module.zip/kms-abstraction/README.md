# SākshyaChain — KMS Abstraction + Digital Signature Module

Drop-in implementation of the **"Digital Signature Feature — Complete
Architecture"** diagram, built behind a swappable KMS interface so today's
demo (server-custodied keys) and tomorrow's production system (AWS KMS,
private key never leaves the HSM boundary) are the *same code path*.

## What's here

```
src/kms/
  KMSProvider.js            interface every provider must implement
  KMSFactory.js              picks a provider based on KMS_PROVIDER env var
  index.js                   facade — the ONLY module the rest of the app should import
  providers/
    LocalKmsProvider.js      dev/MVP: master key in env, RSA keys encrypted on disk
    AwsKmsProvider.js        production: AWS KMS GenerateDataKey/Decrypt/Sign/Verify

src/services/
  signatureService.js        builds canonical manifests, signs, verifies, revokes

src/routes/
  signatureRoutes.js         REST endpoints matching the architecture diagram

src/middleware/authPlaceholder.js   dev-only stand-in for your real auth.js
src/app.js                          runnable Express app wiring it together
test/kms.test.js                    unit tests for the KMS layer
test/signature.test.js              integration tests for sign/verify/revoke/tamper-detect
```

## Why it's structured this way

1. **Nothing outside `src/kms/index.js` ever touches raw crypto or a specific
   provider.** `cryptoService`/`signatureService`/route handlers call
   `kms.sign()`, `kms.generateDataKey()`, etc. Migrating from demo to
   production KMS is a config change:

   ```bash
   # Today (MVP demo)
   KMS_PROVIDER=local
   KMS_LOCAL_MASTER_KEY=<64-char hex>

   # Production
   KMS_PROVIDER=aws
   AWS_REGION=ap-south-1
   KMS_SYMMETRIC_KEY_ID=arn:aws:kms:...:key/xxxx
   KMS_SIGNING_KEY_MAP_JSON={"officer_42":"arn:aws:kms:...:key/yyyy"}
   npm install @aws-sdk/client-kms
   ```

   No changes needed anywhere else in the codebase.

2. **Signatures cover a canonical manifest, never the raw file.** The
   manifest binds `{ documentId, versionId, payloadHash, signerId, metadata,
   timestamp }`. `src/utils/canonicalJson.js` guarantees the same logical
   manifest always serializes to the exact same bytes (sorted keys), so the
   digest is reproducible regardless of how the manifest object was
   reconstructed (e.g. from a DB row).

3. **Verification distinguishes three failure modes that mean different
   things in an investigation**:
   - `TAMPER_DETECTED` — the file itself changed after signing
   - `SIGNATURE_INVALID` — the manifest/signature pair doesn't cryptographically verify
   - `SIGNATURE_REVOKED` — cryptographically fine, but explicitly revoked (e.g. compromised key)

   These are reported separately rather than collapsed into one boolean,
   because "the file was tampered with" and "we revoked this later" are very
   different findings in a court context.

4. **Public keys are served without authentication** (`GET
   /api/signers/:signerId/public-key`) on purpose — the whole point is that
   an external party (defense counsel's own tooling, an independent court
   auditor) can verify a signature without trusting this server's session
   layer or its verdict. A public key is not a secret; gating it behind
   login would defeat the purpose of third-party verifiability.

## Honest scope notes

- **`LocalKmsProvider` is the same custody model you already have** — a
  server-held master key protects everything, including RSA signing keys
  stored on disk. This is explicitly a demo/MVP provider, not real
  non-repudiation. Say so if you present it.
- **`AwsKmsProvider.provisionSigningKey()` intentionally throws.** Creating a
  signing CMK with the right key policy is an infrastructure decision that
  should go through IaC/console, not happen implicitly on a hot API path.
- **Master key rotation is not implemented.** If you rotate
  `KMS_LOCAL_MASTER_KEY`, previously-wrapped DEKs and signing keys become
  undecryptable — this is a real limitation worth listing under "Known
  Limitations," not a bug to hide. (We hit exactly this failure mode while
  writing the tests here — see the comment at the top of `test/kms.test.js`.)
- **Audit ledger integration is a commented call site, not wired up.**
  `signatureRoutes.js` shows exactly where to call your real
  `ledgerService.appendEvent(...)` for `SIGN` and `SIGNATURE_REVOKED`
  actions — intentionally left as a TODO so this module doesn't need to
  depend on your ledger's internals.

## Running it

```bash
npm install
KMS_LOCAL_MASTER_KEY=$(node -e "console.log(require('crypto').randomBytes(32).toString('hex'))") npm start
npm test   # runs both test suites, 15 assertions, all passing
```

## Wiring into the existing SākshyaChain backend

1. Copy `src/kms/`, `src/services/signatureService.js`,
   `src/routes/signatureRoutes.js`, `src/utils/canonicalJson.js` into your
   `server/src/` tree.
2. Replace `src/middleware/authPlaceholder.js` usage in
   `signatureRoutes.js` with your real `middleware/auth.js`
   (`authenticateToken`, `authorizeClearance`) — the contract
   (`req.user = { id, role }`) is identical.
3. Uncomment and wire the `ledgerService.appendEvent(...)` calls marked
   `---- Audit hook ----` in `signatureRoutes.js`.
4. Replace the in-memory `_manifestStore`/`_revocations` Maps in
   `signatureService.js` with real Postgres queries against your
   `MANIFESTS`, `SIGNATURES`, and `SIGNATURE_REVOCATIONS` tables — the
   function signatures don't need to change, only the storage calls inside them.
