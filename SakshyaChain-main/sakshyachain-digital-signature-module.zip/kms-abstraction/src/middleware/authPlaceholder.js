/**
 * Placeholder auth middleware — SākshyaChain already has (per the spec)
 * `server/src/middleware/auth.js` with `authenticateToken`, `authorizeClearance`,
 * `authorizeCaseAccess`. Use those in production; this file exists only so
 * signatureRoutes.js is runnable/testable standalone without pulling in the
 * full JWT/session stack.
 *
 * Contract signatureRoutes.js depends on: req.user = { id, role }.
 * Swap this file's export for the real authenticateToken/authorizeClearance
 * chain — no changes needed in signatureRoutes.js itself.
 */
function fakeAuth(req, res, next) {
  const userId = req.header('x-user-id');
  const role = req.header('x-user-role');
  if (!userId) {
    return res.status(401).json({ error: 'Missing x-user-id header (dev auth placeholder)' });
  }
  req.user = { id: userId, role: role || 'OFFICER' };
  next();
}

function requireRole(...allowedRoles) {
  return (req, res, next) => {
    if (!req.user) return res.status(401).json({ error: 'Unauthenticated' });
    if (!allowedRoles.includes(req.user.role)) {
      return res.status(403).json({ error: `Role "${req.user.role}" not permitted for this action` });
    }
    next();
  };
}

module.exports = { fakeAuth, requireRole };
