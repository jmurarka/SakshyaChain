const express = require('express');
const signatureRoutes = require('./routes/signatureRoutes');

function createApp() {
  const app = express();
  app.use(express.json());
  app.use('/api', signatureRoutes);
  app.get('/health', (req, res) => res.json({ status: 'ok' }));
  return app;
}

if (require.main === module) {
  const app = createApp();
  const port = process.env.PORT || 4000;
  app.listen(port, () => {
    // eslint-disable-next-line no-console
    console.log(`Signature service demo listening on :${port}`);
  });
}

module.exports = { createApp };
