/**
 * KMSProvider — abstract contract every key-management backend must implement.
 *
 * This is the seam that lets SākshyaChain swap:
 *   Dev/MVP:    LocalKmsProvider   (master key in env, RSA key encrypted on disk)
 *   Production: AwsKmsProvider     (AES key wrapping + RSA signing inside AWS KMS/CloudHSM)
 *
 * WHY THIS MATTERS (ties directly to two gaps flagged in architecture review):
 *   1. Envelope encryption: today the KEK lives in server config. Behind this
 *      interface, swapping to a real KMS is a one-line env change, not a rewrite.
 *   2. Digital signatures: today RSA private keys are "server-custodied" (a demo
 *      admission, not real non-repudiation). AwsKmsProvider.sign() below calls
 *      KMS's Sign API on an asymmetric CMK — the private key material never
 *      leaves AWS's HSM boundary, which is what makes a signature legally
 *      meaningful. This interface is what makes that upgrade a config change.
 *
 * Every method must be implemented by a concrete provider. Methods throw
 * "Not implemented" in the base class so a half-finished provider fails loudly
 * instead of silently returning undefined.
 */

class KMSProvider {
  /** Machine-readable provider identity, logged into every audit event so the
   *  ledger can prove *which* key-custody model protected a given action.
   *  e.g. "local-dev-v1", "aws-kms-ap-south-1"
   */
  get providerName() {
    throw new Error('KMSProvider.providerName must be implemented by subclass');
  }

  /**
   * Generate a new Data Encryption Key (DEK) for envelope encryption.
   * @param {string} keyId - logical key/document identifier (used for audit + rotation)
   * @returns {Promise<{plaintextKey: Buffer, wrappedKey: string, provider: string}>}
   *   plaintextKey: raw 32-byte AES key — caller uses it ONCE in memory, then discards it.
   *   wrappedKey:   the DEK, encrypted under the KEK/CMK — this is what gets persisted.
   */
  async generateDataKey(keyId) {
    throw new Error('Not implemented: generateDataKey');
  }

  /**
   * Unwrap a previously wrapped DEK for decryption.
   * @param {string} wrappedKey
   * @param {string} keyId
   * @returns {Promise<Buffer>} plaintext 32-byte AES key, in memory only
   */
  async unwrapDataKey(wrappedKey, keyId) {
    throw new Error('Not implemented: unwrapDataKey');
  }

  /**
   * Sign a digest (e.g. SHA-256 of a canonical manifest) using an
   * asymmetric signing key. Private key material must never leave this
   * method's boundary — in AwsKmsProvider, it never leaves AWS at all.
   * @param {string} keyId - which signer's key to use (e.g. officer/user id)
   * @param {Buffer} digest - the SHA-256 digest to sign, NOT the raw document
   * @returns {Promise<{signature: string, keyId: string, provider: string, signedAt: string}>}
   */
  async sign(keyId, digest) {
    throw new Error('Not implemented: sign');
  }

  /**
   * Verify a signature against a digest.
   * @returns {Promise<boolean>}
   */
  async verify(keyId, digest, signatureBase64) {
    throw new Error('Not implemented: verify');
  }

  /**
   * Return the public key (SPKI, PEM) for a signer, for external verification
   * (e.g. a defense attorney's own tooling verifying a forensic signature).
   * @returns {Promise<string>} PEM-encoded public key
   */
  async getPublicKey(keyId) {
    throw new Error('Not implemented: getPublicKey');
  }

  /**
   * Provision a new signing keypair for a signer (called once, e.g. at
   * officer onboarding). Idempotent: if keyId already exists, returns it.
   * @returns {Promise<{keyId: string, publicKey: string}>}
   */
  async provisionSigningKey(keyId) {
    throw new Error('Not implemented: provisionSigningKey');
  }
}

module.exports = KMSProvider;
