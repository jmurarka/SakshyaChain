const KMSProvider = require('../KMSProvider');

/**
 * AwsKmsProvider — production implementation backed by real AWS KMS.
 *
 * THIS is what actually fixes the two flagged gaps for real:
 *   - Envelope encryption: GenerateDataKey/Decrypt call out to a symmetric CMK.
 *     The KEK itself never appears in application memory or config — only
 *     AWS KMS's HSM boundary ever holds it.
 *   - Digital signatures: uses an ASYMMETRIC CMK (RSA_2048) with the Sign API.
 *     The private key is generated inside, and never leaves, AWS KMS/CloudHSM.
 *     This is what makes a signature legally meaningful non-repudiation,
 *     versus the LocalKmsProvider's "server-custodied, demo only" model.
 *
 * Lazy-requires @aws-sdk/client-kms so this file can exist in the repo and be
 * read/reviewed without forcing every developer to install the AWS SDK just
 * to run the app in local-dev mode.
 *
 * Config (env):
 *   KMS_PROVIDER=aws
 *   AWS_REGION=ap-south-1
 *   KMS_SYMMETRIC_KEY_ID=arn:aws:kms:...:key/xxxx   (for envelope encryption)
 *   KMS_SIGNING_KEY_MAP_JSON={"officer_42":"arn:aws:kms:...:key/yyyy", ...}
 *     -> in production this mapping usually lives in a small DB table
 *        (signing_keys: user_id -> cmk_arn), not an env var; the JSON env
 *        var here is just the simplest thing that works for a first cutover.
 */
class AwsKmsProvider extends KMSProvider {
  constructor() {
    super();
    let KMSClient, GenerateDataKeyCommand, DecryptCommand, SignCommand, VerifyCommand, GetPublicKeyCommand;
    try {
      // eslint-disable-next-line global-require
      ({ KMSClient, GenerateDataKeyCommand, DecryptCommand, SignCommand, VerifyCommand, GetPublicKeyCommand } =
        require('@aws-sdk/client-kms'));
    } catch (err) {
      throw new Error(
        'AwsKmsProvider requires the "@aws-sdk/client-kms" package. ' +
        'Install it with: npm install @aws-sdk/client-kms\n' +
        `Original error: ${err.message}`
      );
    }
    this._cmds = { GenerateDataKeyCommand, DecryptCommand, SignCommand, VerifyCommand, GetPublicKeyCommand };
    this._client = new KMSClient({ region: process.env.AWS_REGION || 'ap-south-1' });
    this._symmetricKeyId = requireEnv('KMS_SYMMETRIC_KEY_ID');
    this._signingKeyMap = JSON.parse(process.env.KMS_SIGNING_KEY_MAP_JSON || '{}');
  }

  get providerName() {
    return `aws-kms-${process.env.AWS_REGION || 'ap-south-1'}`;
  }

  _resolveSigningKeyArn(keyId) {
    const arn = this._signingKeyMap[keyId];
    if (!arn) {
      throw new Error(
        `No AWS KMS signing key ARN mapped for keyId "${keyId}". ` +
        `Provision a CMK for this user and add it to KMS_SIGNING_KEY_MAP_JSON ` +
        `(or the signing_keys DB table in production).`
      );
    }
    return arn;
  }

  // ---- Envelope encryption ----

  async generateDataKey(/* keyId */) {
    const { GenerateDataKeyCommand } = this._cmds;
    const res = await this._client.send(
      new GenerateDataKeyCommand({ KeyId: this._symmetricKeyId, KeySpec: 'AES_256' })
    );
    return {
      plaintextKey: Buffer.from(res.Plaintext), // in memory only — caller must discard after use
      wrappedKey: Buffer.from(res.CiphertextBlob).toString('base64'),
      provider: this.providerName,
    };
  }

  async unwrapDataKey(wrappedKey /*, keyId */) {
    const { DecryptCommand } = this._cmds;
    const res = await this._client.send(
      new DecryptCommand({
        CiphertextBlob: Buffer.from(wrappedKey, 'base64'),
        KeyId: this._symmetricKeyId,
      })
    );
    return Buffer.from(res.Plaintext);
  }

  // ---- Signing — private key never leaves AWS KMS ----

  async provisionSigningKey(keyId) {
    // Real CMK creation (CreateKey with KeyUsage=SIGN_VERIFY, KeySpec=RSA_2048)
    // is an infrastructure operation done via IaC/console with proper key
    // policies, not a hot-path API call. This method intentionally throws
    // to force that decision to be made deliberately, not accidentally at
    // runtime with default (probably wrong) key policies.
    throw new Error(
      `provisionSigningKey is not supported at runtime for AwsKmsProvider. ` +
      `Provision a CMK (KeyUsage=SIGN_VERIFY, KeySpec=RSA_2048) via IaC for ` +
      `keyId "${keyId}", then add its ARN to KMS_SIGNING_KEY_MAP_JSON.`
    );
  }

  async getPublicKey(keyId) {
    const { GetPublicKeyCommand } = this._cmds;
    const arn = this._resolveSigningKeyArn(keyId);
    const res = await this._client.send(new GetPublicKeyCommand({ KeyId: arn }));
    const der = Buffer.from(res.PublicKey);
    const b64 = der.toString('base64').match(/.{1,64}/g).join('\n');
    return `-----BEGIN PUBLIC KEY-----\n${b64}\n-----END PUBLIC KEY-----\n`;
  }

  async sign(keyId, digest) {
    const { SignCommand } = this._cmds;
    const arn = this._resolveSigningKeyArn(keyId);
    const res = await this._client.send(
      new SignCommand({
        KeyId: arn,
        Message: digest,
        MessageType: 'DIGEST',
        SigningAlgorithm: 'RSASSA_PKCS1_V1_5_SHA_256',
      })
    );
    return {
      signature: Buffer.from(res.Signature).toString('base64'),
      keyId,
      provider: this.providerName,
      signedAt: new Date().toISOString(),
    };
  }

  async verify(keyId, digest, signatureBase64) {
    const { VerifyCommand } = this._cmds;
    const arn = this._resolveSigningKeyArn(keyId);
    const res = await this._client.send(
      new VerifyCommand({
        KeyId: arn,
        Message: digest,
        MessageType: 'DIGEST',
        Signature: Buffer.from(signatureBase64, 'base64'),
        SigningAlgorithm: 'RSASSA_PKCS1_V1_5_SHA_256',
      })
    );
    return res.SignatureValid === true;
  }
}

function requireEnv(name) {
  const v = process.env[name];
  if (!v) throw new Error(`Missing required env var: ${name}`);
  return v;
}

module.exports = AwsKmsProvider;
