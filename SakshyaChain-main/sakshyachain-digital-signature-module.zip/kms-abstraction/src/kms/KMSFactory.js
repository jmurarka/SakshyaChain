/**
 * KMSFactory — the entire "swap KMS backend" surface area.
 *
 * To migrate SākshyaChain from demo key custody to real KMS-backed custody:
 *   1. Set KMS_PROVIDER=aws in production .env
 *   2. Set AWS_REGION, KMS_SYMMETRIC_KEY_ID, KMS_SIGNING_KEY_MAP_JSON
 *   3. npm install @aws-sdk/client-kms
 *   4. Restart. No other code changes anywhere in the app.
 *
 * Nothing in cryptoService.js, signatureService.js, or any route handler
 * ever imports LocalKmsProvider or AwsKmsProvider directly — they only ever
 * import ./index.js (the facade), which asks this factory for whichever
 * provider is configured.
 */
let _instance = null;

function getKmsProvider() {
  if (_instance) return _instance;

  const providerKey = (process.env.KMS_PROVIDER || 'local').toLowerCase();

  switch (providerKey) {
    case 'local': {
      const LocalKmsProvider = require('./providers/LocalKmsProvider');
      _instance = new LocalKmsProvider();
      break;
    }
    case 'aws': {
      const AwsKmsProvider = require('./providers/AwsKmsProvider');
      _instance = new AwsKmsProvider();
      break;
    }
    default:
      throw new Error(
        `Unknown KMS_PROVIDER "${providerKey}". Expected "local" or "aws". ` +
        `(Add a new case here + a new provider class to support e.g. "vault" or "hsm".)`
      );
  }

  // eslint-disable-next-line no-console
  console.log(`[KMSFactory] Using KMS provider: ${_instance.providerName}`);
  return _instance;
}

/** Test-only: force re-creation of the provider (e.g. after changing env vars in tests). */
function _resetForTests() {
  _instance = null;
}

module.exports = { getKmsProvider, _resetForTests };
