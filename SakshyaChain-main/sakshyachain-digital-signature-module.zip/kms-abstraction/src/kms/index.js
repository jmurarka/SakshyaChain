const { getKmsProvider } = require('./KMSFactory');

/**
 * This file is the ONLY module the rest of the app should import from `kms/`.
 * cryptoService.js, signatureService.js, and route handlers call these
 * functions — never LocalKmsProvider/AwsKmsProvider directly. That's what
 * makes the provider swap (see KMSFactory.js) a config change, not a refactor.
 */

async function generateDataKey(keyId) {
  return getKmsProvider().generateDataKey(keyId);
}

async function unwrapDataKey(wrappedKey, keyId) {
  return getKmsProvider().unwrapDataKey(wrappedKey, keyId);
}

async function provisionSigningKey(keyId) {
  return getKmsProvider().provisionSigningKey(keyId);
}

async function getPublicKey(keyId) {
  return getKmsProvider().getPublicKey(keyId);
}

async function sign(keyId, digest) {
  return getKmsProvider().sign(keyId, digest);
}

async function verify(keyId, digest, signatureBase64) {
  return getKmsProvider().verify(keyId, digest, signatureBase64);
}

function providerName() {
  return getKmsProvider().providerName;
}

module.exports = {
  generateDataKey,
  unwrapDataKey,
  provisionSigningKey,
  getPublicKey,
  sign,
  verify,
  providerName,
};
