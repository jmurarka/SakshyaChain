const express = require('express');
const signatureService = require('../services/signatureService');
const { fakeAuth, requireRole } = require('../middleware/authPlaceholder');

const router = express.Router();

/**
 * Only roles that can legitimately attest to a document should be allowed to
 * sign. Matches the persona list from the spec: forensic experts sign lab
 * reports, judges sign orders, etc. Adjust to your real role enum.
 */
const SIGNER_ROLES = ['FORENSIC_SPECIALIST', 'JUDGE', 'PROSECUTOR', 'OFFICER'];
const REVOKER_ROLES = ['COMPLIANCE_AUDITOR', 'ADMIN'];

/**
 * IMPORTANT: /signers/:signerId/public-key is intentionally mounted BEFORE
 * fakeAuth below. Its entire purpose is to let a party outside this system
 * (defense counsel's own verification tooling, a court's independent audit
 * software) verify a signature WITHOUT trusting this server's session/auth —
 * that's what makes it real third-party verifiability rather than "trust us."
 * Gating it behind an internal login would defeat that purpose. It is safe to
 * expose without auth because a public key is, by definition, not secret.
 */
router.get('/signers/:signerId/public-key', async (req, res) => {
  try {
    const kms = require('../kms');
    const publicKey = await kms.getPublicKey(req.params.signerId);
    res.type('text/plain').send(publicKey);
  } catch (err) {
    res.status(404).json({ error: err.message });
  }
});

// Everything below this line requires an authenticated session.
router.use(fakeAuth);

/**
 * POST /api/documents/:documentId/versions/:versionId/sign
 * body: { payloadHash, metadata? }
 *
 * NOTE: signerId is taken from the authenticated session (req.user.id), never
 * from the request body — otherwise anyone could sign as anyone else.
 */
router.post('/documents/:documentId/versions/:versionId/sign', requireRole(...SIGNER_ROLES), async (req, res) => {
  const { documentId, versionId } = req.params;
  const { payloadHash, metadata } = req.body || {};

  if (!payloadHash) {
    return res.status(400).json({ error: 'payloadHash is required (recompute SHA-256 of the stored file server-side, do not trust a client-supplied hash blindly)' });
  }

  try {
    const record = await signatureService.signManifest({
      documentId,
      versionId,
      payloadHash,
      signerId: req.user.id,
      metadata,
    });

    // ---- Audit hook (wire to your real ledgerService) ----
    // await ledgerService.appendEvent({
    //   action: 'SIGN',
    //   actorId: req.user.id,
    //   documentId,
    //   docHash: payloadHash,
    //   details: { manifestId: record.manifestId, signatureId: record.signatureId, provider: record.signatureProvider },
    // });

    return res.status(201).json({
      manifestId: record.manifestId,
      signatureId: record.signatureId,
      documentId: record.documentId,
      versionId: record.versionId,
      signerId: record.signerId,
      provider: record.signatureProvider,
      signedAt: record.signedAt,
    });
  } catch (err) {
    return res.status(500).json({ error: err.message });
  }
});

/**
 * GET /api/documents/:documentId/signatures
 * Returns all signatures ever applied to any version of this document
 * (chain-of-custody: "who signed off on this at each stage").
 */
router.get('/documents/:documentId/signatures', async (req, res) => {
  const records = await signatureService.listSignaturesForDocument(req.params.documentId);
  res.json(
    records.map((r) => ({
      manifestId: r.manifestId,
      versionId: r.versionId,
      signerId: r.signerId,
      signatureId: r.signatureId,
      provider: r.signatureProvider,
      signedAt: r.signedAt,
      status: r.status,
    }))
  );
});

/**
 * POST /api/signatures/manifests/:manifestId/verify
 * body: { currentPayloadHash? }  — pass this to also catch file-level tampering
 *
 * Returns one of: VERIFIED | TAMPER_DETECTED | SIGNATURE_INVALID | SIGNATURE_REVOKED | NOT_FOUND
 * This is the "Cryptographically Signed & Verified" badge endpoint.
 */
router.post('/signatures/manifests/:manifestId/verify', async (req, res) => {
  const { currentPayloadHash } = req.body || {};
  const result = await signatureService.verifyManifest(req.params.manifestId, currentPayloadHash);
  const httpStatus = result.status === 'NOT_FOUND' ? 404 : 200;
  res.status(httpStatus).json(result);
});

/**
 * DELETE /api/signatures/:signatureId
 * body: { reason }
 * Restricted to compliance/admin roles — matches "Compliance & Security
 * Auditor" persona from the spec ("checks security violations").
 */
router.delete('/signatures/:signatureId', requireRole(...REVOKER_ROLES), async (req, res) => {
  const { reason } = req.body || {};
  if (!reason) return res.status(400).json({ error: 'reason is required to revoke a signature' });
  try {
    const revocation = await signatureService.revokeSignature(req.params.signatureId, {
      reason,
      revokedBy: req.user.id,
    });

    // ---- Audit hook ----
    // await ledgerService.appendEvent({ action: 'SIGNATURE_REVOKED', actorId: req.user.id, details: { signatureId: req.params.signatureId, reason } });

    res.json({ signatureId: req.params.signatureId, ...revocation });
  } catch (err) {
    res.status(404).json({ error: err.message });
  }
});

module.exports = router;
