const crypto = require('crypto');
const kms = require('../kms');
const { canonicalize } = require('../utils/canonicalJson');

/**
 * signatureService — implements the "Digital Signature Feature" diagram:
 *
 *   CLIENT --sign--> API GATEWAY --> SIGNATURE SERVICE (this file)
 *                                       |-- builds manifest
 *                                       |-- computes SHA-256 of manifest
 *                                       |-- calls KMS/HSM to sign            <-- via kms facade, never raw crypto
 *                                       |-- stores signature (Manifest DB)
 *                                       '-- emits audit event (SIGN)         <-- caller wires this to ledgerService
 *
 * KEY DESIGN DECISION: we sign the CANONICAL MANIFEST, never the raw file.
 * The manifest binds together { documentId, versionId, payloadHash, metadata,
 * timestamp } into one object; signing that (not the file bytes directly)
 * means:
 *   - the same signing flow works for any file type/size uniformly
 *   - metadata changes force a new manifest + new signature, instead of
 *     silently invalidating an old one with no record of why
 *   - verification can detect BOTH "the file changed" (payloadHash mismatch)
 *     AND "the manifest was tampered with" (digest/signature mismatch) as
 *     two distinct, separately-reportable failure modes — see verifyManifest.
 *
 * STORAGE: `_manifestStore` / `_revocations` below stand in for the
 * "MANIFEST DB (Postgres)" and "SIGNATURE_REVOCATIONS" table in the ER
 * diagram. Swap them for real repository calls (pg/knex/prisma) — nothing
 * in the signing/verification LOGIC below needs to change, only how records
 * are persisted and fetched.
 */

// ---- In-memory stand-ins for MANIFEST DB / SIGNATURE_REVOCATIONS ----
const _manifestStore = new Map(); // manifestId -> manifest record
const _byDocument = new Map(); // documentId -> [manifestId, ...]
const _revocations = new Map(); // signatureId -> { reason, revokedBy, revokedAt }

function newId(prefix) {
  return `${prefix}-${crypto.randomBytes(8).toString('hex')}`;
}

/**
 * Build the canonical manifest object for a document version.
 * This object (minus signature/signatureId, which don't exist yet) is what
 * actually gets hashed and signed.
 */
function buildManifest({ documentId, versionId, payloadHash, signerId, metadata = {} }) {
  if (!documentId || !versionId || !payloadHash || !signerId) {
    throw new Error('buildManifest requires documentId, versionId, payloadHash, signerId');
  }
  return {
    manifestId: newId('MANIFEST'),
    documentId,
    versionId,
    sha256: payloadHash, // the document's own content hash, bound into the manifest
    signerId,
    metadata, // e.g. { docTitle, caseId, clearanceLevel } — anything worth binding into the signature
    timestamp: new Date().toISOString(),
  };
}

/** SHA-256 digest of the canonicalized manifest (excludes signature fields, which don't exist yet at this point). */
function computeManifestDigest(manifest) {
  const canonicalString = canonicalize(manifest);
  return crypto.createHash('sha256').update(canonicalString).digest();
}

/**
 * Sign a document version.
 *
 * @param {object} params { documentId, versionId, payloadHash, signerId, metadata }
 * @returns {Promise<object>} the stored, signed manifest record
 *
 * Emits no audit event itself — returns everything the caller needs
 * (manifestId, signatureId, documentId, signerId, provider) to append a
 * SIGN block to the ledger. Keeping that call at the route/orchestration
 * layer avoids this service depending on the ledger module directly.
 */
async function signManifest({ documentId, versionId, payloadHash, signerId, metadata }) {
  // Ensure the signer has a key. For LocalKmsProvider this provisions one
  // on first use (dev convenience). For AwsKmsProvider this throws with a
  // clear message directing you to provision a CMK via IaC — see
  // AwsKmsProvider.provisionSigningKey for why that's intentional.
  await kms.provisionSigningKey(signerId).catch((err) => {
    // If the key already exists (local) this never throws; if it's AWS and
    // genuinely unprovisioned, re-throw with the actionable message intact.
    throw err;
  });

  const manifest = buildManifest({ documentId, versionId, payloadHash, signerId, metadata });
  const digest = computeManifestDigest(manifest);
  const signResult = await kms.sign(signerId, digest);

  const record = {
    ...manifest,
    signatureId: newId('SIG'),
    signature: signResult.signature,
    signatureProvider: signResult.provider,
    signedAt: signResult.signedAt,
    status: 'ACTIVE', // ACTIVE | REVOKED
  };

  _manifestStore.set(record.manifestId, record);
  const list = _byDocument.get(documentId) || [];
  list.push(record.manifestId);
  _byDocument.set(documentId, list);

  return record;
}

/**
 * Verify a stored signature.
 *
 * Distinguishes THREE independent failure modes, because they mean very
 * different things in an investigation/court context:
 *
 *   DOCUMENT_TAMPERED   - the file's current content hash no longer matches
 *                          what was signed. The file itself was altered
 *                          after signing. (Only checked if currentPayloadHash given.)
 *   SIGNATURE_INVALID   - the manifest/signature pair doesn't cryptographically
 *                          verify. Either the manifest record was tampered
 *                          with in the DB, or the signature is forged/corrupt.
 *   SIGNATURE_REVOKED   - the signature is cryptographically valid but has
 *                          been explicitly revoked (e.g. signer's key was
 *                          later found compromised, or the signature was
 *                          issued in error).
 *
 * @param {string} manifestId
 * @param {string} [currentPayloadHash] - recompute this from the live file
 *   on disk/object storage and pass it in to also catch post-signing file
 *   tampering, not just manifest/signature tampering.
 */
async function verifyManifest(manifestId, currentPayloadHash) {
  const record = _manifestStore.get(manifestId);
  if (!record) {
    return { valid: false, status: 'NOT_FOUND', reasons: ['No manifest with this id exists'] };
  }

  const reasons = [];

  // 1. Was it revoked?
  const revocation = _revocations.get(record.signatureId);
  if (revocation) {
    reasons.push(`Signature revoked at ${revocation.revokedAt}: ${revocation.reason}`);
  }

  // 2. Does the file on disk still match what was signed?
  let documentTampered = false;
  if (currentPayloadHash && currentPayloadHash !== record.sha256) {
    documentTampered = true;
    reasons.push(
      `Document content hash mismatch: signed=${record.sha256}, current=${currentPayloadHash}`
    );
  }

  // 3. Cryptographic verification — rebuild the EXACT manifest that was
  //    signed (strip fields added after signing) and recompute the digest.
  const { signatureId, signature, signatureProvider, signedAt, status, ...signedManifest } = record;
  const digest = computeManifestDigest(signedManifest);
  let signatureCryptoValid = false;
  try {
    signatureCryptoValid = await kms.verify(record.signerId, digest, signature);
  } catch (err) {
    reasons.push(`Verification error: ${err.message}`);
  }
  if (!signatureCryptoValid) {
    reasons.push('Cryptographic signature verification failed — manifest or signature may be corrupted/forged');
  }

  let overallStatus = 'VERIFIED';
  if (documentTampered) overallStatus = 'TAMPER_DETECTED';
  else if (!signatureCryptoValid) overallStatus = 'SIGNATURE_INVALID';
  else if (revocation) overallStatus = 'SIGNATURE_REVOKED';

  return {
    valid: overallStatus === 'VERIFIED',
    status: overallStatus,
    reasons,
    manifest: {
      manifestId: record.manifestId,
      documentId: record.documentId,
      versionId: record.versionId,
      signerId: record.signerId,
      signatureId: record.signatureId,
      signedAt: record.signedAt,
      provider: record.signatureProvider,
    },
  };
}

async function listSignaturesForDocument(documentId) {
  const ids = _byDocument.get(documentId) || [];
  return ids.map((id) => _manifestStore.get(id)).filter(Boolean);
}

async function getManifest(manifestId) {
  return _manifestStore.get(manifestId) || null;
}

/**
 * Revoke a signature. Does NOT delete or mutate the original manifest
 * record (that would defeat the append-only audit principle) — it adds a
 * separate revocation record, mirroring the SIGNATURE_REVOCATIONS table in
 * the ER diagram. Verification checks this table on every call.
 */
async function revokeSignature(signatureId, { reason, revokedBy }) {
  if (!reason || !revokedBy) {
    throw new Error('revokeSignature requires { reason, revokedBy }');
  }
  const exists = [..._manifestStore.values()].some((m) => m.signatureId === signatureId);
  if (!exists) {
    throw new Error(`No signature found with id "${signatureId}"`);
  }
  const revocation = { reason, revokedBy, revokedAt: new Date().toISOString() };
  _revocations.set(signatureId, revocation);
  return revocation;
}

module.exports = {
  buildManifest,
  computeManifestDigest,
  signManifest,
  verifyManifest,
  listSignaturesForDocument,
  getManifest,
  revokeSignature,
  // exported for tests only
  _internal: { _manifestStore, _revocations },
};
