/**
 * canonicalize — deterministic JSON serialization.
 *
 * Why this matters for signatures: `JSON.stringify({a:1,b:2})` and
 * `JSON.stringify({b:2,a:1})` produce different strings for the "same" object.
 * If the manifest is ever rebuilt (e.g. during verification, or reconstructed
 * from a DB row where column order differs) with keys in a different order,
 * a naive sha256(JSON.stringify(manifest)) would produce a DIFFERENT digest
 * for logically identical data — causing false-positive tamper alerts.
 *
 * This function recursively sorts object keys before stringifying so the
 * same logical manifest always produces the exact same byte string, and
 * therefore the exact same digest, no matter how it was constructed.
 *
 * Arrays are NOT reordered — array order is semantically meaningful
 * (e.g. parent_hashes order in the audit DAG) and must be preserved exactly
 * as given.
 */
function canonicalize(value) {
  return JSON.stringify(sortKeysDeep(value));
}

function sortKeysDeep(value) {
  if (Array.isArray(value)) {
    return value.map(sortKeysDeep);
  }
  if (value !== null && typeof value === 'object') {
    const sorted = {};
    for (const key of Object.keys(value).sort()) {
      sorted[key] = sortKeysDeep(value[key]);
    }
    return sorted;
  }
  return value;
}

module.exports = { canonicalize, sortKeysDeep };
