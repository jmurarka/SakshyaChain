const assert = require('assert');
const crypto = require('crypto');
const os = require('os');
const path = require('path');
const fs = require('fs');

// See test/kms.test.js for why this isolated temp vault dir is necessary.
const tmpVaultDir = fs.mkdtempSync(path.join(os.tmpdir(), 'sakshyachain-sig-test-'));
process.env.KMS_LOCAL_VAULT_DIR = tmpVaultDir;
process.env.KMS_PROVIDER = 'local';
process.env.KMS_LOCAL_MASTER_KEY = crypto.randomBytes(32).toString('hex');

const { _resetForTests } = require('../src/kms/KMSFactory');
_resetForTests();
const signatureService = require('../src/services/signatureService');

function sha256hex(str) {
  return crypto.createHash('sha256').update(str).digest('hex');
}

async function run() {
  console.log('--- Digital Signature Service tests ---');

  const originalContent = 'FORENSIC REPORT: Ballistics analysis, case CASE-2026-8891, v1.0';
  const originalHash = sha256hex(originalContent);

  // 1. Sign a manifest
  const record = await signatureService.signManifest({
    documentId: 'DOC-8891-002',
    versionId: 'v1.0',
    payloadHash: originalHash,
    signerId: 'forensic_8',
    metadata: { docTitle: 'Forensic Ballistics & DNA Analysis', caseId: 'CASE-2026-8891' },
  });
  assert.ok(record.signatureId, 'should return a signatureId');
  assert.ok(record.manifestId, 'should return a manifestId');
  console.log(`[PASS] signManifest -> manifestId=${record.manifestId}, signatureId=${record.signatureId}`);

  // 2. Verify immediately — should be VERIFIED (document unchanged)
  const verifyOk = await signatureService.verifyManifest(record.manifestId, originalHash);
  assert.strictEqual(verifyOk.status, 'VERIFIED', `expected VERIFIED, got ${verifyOk.status}: ${verifyOk.reasons}`);
  assert.strictEqual(verifyOk.valid, true);
  console.log('[PASS] verifyManifest returns VERIFIED for unmodified document');

  // 3. Simulate document tampering: file content changed after signing
  const tamperedContent = 'FORENSIC REPORT: Ballistics analysis, case CASE-2026-8891, v1.0 -- EDITED BY ATTACKER';
  const tamperedHash = sha256hex(tamperedContent);
  const verifyTampered = await signatureService.verifyManifest(record.manifestId, tamperedHash);
  assert.strictEqual(verifyTampered.status, 'TAMPER_DETECTED', `expected TAMPER_DETECTED, got ${verifyTampered.status}`);
  assert.strictEqual(verifyTampered.valid, false);
  console.log('[PASS] verifyManifest correctly flags TAMPER_DETECTED when file content changed post-signing');

  // 4. Verify without a currentPayloadHash still cryptographically validates the manifest itself
  const verifyNoHashCheck = await signatureService.verifyManifest(record.manifestId);
  assert.strictEqual(verifyNoHashCheck.status, 'VERIFIED');
  console.log('[PASS] verifyManifest works when caller only wants signature integrity, not file-freshness check');

  // 5. Unknown manifest id
  const verifyMissing = await signatureService.verifyManifest('MANIFEST-does-not-exist');
  assert.strictEqual(verifyMissing.status, 'NOT_FOUND');
  console.log('[PASS] verifyManifest returns NOT_FOUND for unknown manifestId');

  // 6. Revocation
  await signatureService.revokeSignature(record.signatureId, {
    reason: 'Signer key later found on a compromised laptop',
    revokedBy: 'compliance_auditor_1',
  });
  const verifyAfterRevoke = await signatureService.verifyManifest(record.manifestId, originalHash);
  assert.strictEqual(verifyAfterRevoke.status, 'SIGNATURE_REVOKED');
  assert.strictEqual(verifyAfterRevoke.valid, false);
  console.log('[PASS] verifyManifest returns SIGNATURE_REVOKED after revocation, even though crypto + hash still check out');

  // 7. Revoking twice / unknown signature id fails loudly instead of silently
  await assert.rejects(
    () => signatureService.revokeSignature('SIG-does-not-exist', { reason: 'x', revokedBy: 'y' }),
    /No signature found/,
    'revoking a nonexistent signature should throw'
  );
  console.log('[PASS] revoking unknown signatureId throws instead of silently succeeding');

  // 8. Two different versions of the same document can both carry independent signatures
  const record2 = await signatureService.signManifest({
    documentId: 'DOC-8891-002',
    versionId: 'v1.1',
    payloadHash: sha256hex(originalContent + ' -- addendum'),
    signerId: 'forensic_8',
    metadata: { docTitle: 'Forensic Ballistics & DNA Analysis (Addendum)' },
  });
  const allSignatures = await signatureService.listSignaturesForDocument('DOC-8891-002');
  assert.strictEqual(allSignatures.length, 2, 'both v1.0 and v1.1 signatures should be listed for the document');
  console.log('[PASS] listSignaturesForDocument returns full custody trail across versions');
  void record2;

  console.log('\nALL DIGITAL SIGNATURE TESTS PASSED\n');
}

run().catch((err) => {
  console.error('SIGNATURE TEST FAILURE:', err);
  process.exit(1);
});
