const assert = require('assert');
const crypto = require('crypto');
const os = require('os');
const path = require('path');
const fs = require('fs');

// Isolate this test run's vault dir from other runs/other test files — the
// LocalKmsProvider persists signing keys to disk keyed only by keyId, wrapped
// under the process's master key. Reusing a vault dir across processes that
// each generate a fresh random master key causes stale, undecryptable key
// files (a real-world analog of "rotated the master key without re-wrapping
// existing keys" — worth knowing about even outside of tests).
const tmpVaultDir = fs.mkdtempSync(path.join(os.tmpdir(), 'sakshyachain-kms-test-'));
process.env.KMS_LOCAL_VAULT_DIR = tmpVaultDir;
process.env.KMS_PROVIDER = 'local';
process.env.KMS_LOCAL_MASTER_KEY = crypto.randomBytes(32).toString('hex');

const { _resetForTests } = require('../src/kms/KMSFactory');
_resetForTests();
const kms = require('../src/kms');

async function run() {
  console.log('--- KMS abstraction layer tests (LocalKmsProvider) ---');

  // 1. Envelope encryption round trip
  const { plaintextKey, wrappedKey } = await kms.generateDataKey('doc-1');
  assert.strictEqual(plaintextKey.length, 32, 'DEK should be 32 bytes');
  const unwrapped = await kms.unwrapDataKey(wrappedKey, 'doc-1');
  assert.deepStrictEqual(unwrapped, plaintextKey, 'unwrapped DEK must match original plaintext key');
  console.log('[PASS] generateDataKey / unwrapDataKey round trip');

  // 2. Wrapped key is NOT the plaintext key (sanity check it's actually encrypted)
  assert.notStrictEqual(wrappedKey, plaintextKey.toString('base64'));
  console.log('[PASS] wrappedKey is not plaintext');

  // 3. Provision a signing key + get public key
  const { publicKey } = await kms.provisionSigningKey('officer_42');
  assert.ok(publicKey.includes('BEGIN PUBLIC KEY'), 'should return a PEM public key');
  console.log('[PASS] provisionSigningKey returns PEM public key');

  // 4. Sign + verify round trip
  const digest = crypto.createHash('sha256').update('hello evidence').digest();
  const signResult = await kms.sign('officer_42', digest);
  assert.ok(signResult.signature, 'signature should be present');
  const isValid = await kms.verify('officer_42', digest, signResult.signature);
  assert.strictEqual(isValid, true, 'valid signature must verify true');
  console.log('[PASS] sign / verify round trip');

  // 5. Tampered digest must fail verification
  const tamperedDigest = crypto.createHash('sha256').update('hello TAMPERED evidence').digest();
  const isValidTampered = await kms.verify('officer_42', tamperedDigest, signResult.signature);
  assert.strictEqual(isValidTampered, false, 'signature must NOT verify against a different digest');
  console.log('[PASS] tampered digest correctly fails verification');

  // 6. Signing with an unprovisioned key must fail loudly, not silently succeed —
  //    this matches real KMS behavior (you cannot sign with a CMK that was never
  //    created), so LocalKmsProvider intentionally does NOT auto-provision on sign.
  const digest2 = crypto.createHash('sha256').update('second signer').digest();
  await assert.rejects(
    () => kms.sign('officer_unprovisioned', digest2),
    /No signing key provisioned/,
    'signing with an unprovisioned keyId must throw, not silently succeed'
  );
  console.log('[PASS] signing an unprovisioned key correctly throws (matches real-KMS semantics)');

  // 6b. After explicit provisioning, signing that same keyId works fine.
  await kms.provisionSigningKey('officer_99');
  const signResult2 = await kms.sign('officer_99', digest2);
  assert.ok(signResult2.signature, 'signing works after explicit provisioning');
  console.log('[PASS] signing succeeds after explicit provisionSigningKey call');

  // 7. Wrong signer's key must not verify another signer's signature
  const crossCheck = await kms.verify('officer_99', digest, signResult.signature);
  assert.strictEqual(crossCheck, false, 'officer_99 public key must not validate officer_42 signature');
  console.log('[PASS] cross-signer verification correctly rejected');

  console.log('\nALL KMS TESTS PASSED\n');
}

run().catch((err) => {
  console.error('KMS TEST FAILURE:', err);
  process.exit(1);
});
